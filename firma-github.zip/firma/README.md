# Íconos para firma de correo – Francisco Salgado (ComexTech)

Imágenes con URL fija para la firma de correo. Se publican con GitHub Pages.

## Cómo publicarlo (una sola vez, ~5 minutos)

1. Entra a https://github.com/new
   - **Repository name:** `firma`
   - Márcalo como **Public** (GitHub Pages gratis requiere repo público)
   - Clic en **Create repository**
2. En el repo nuevo, clic en **uploading an existing file** y arrastra **todo el contenido** de esta carpeta (incluida la carpeta `iconos`). Clic en **Commit changes**.
3. Agrega el ícono de LinkedIn: descarga el ícono oficial desde
   https://brand.linkedin.com (sección *"In" logo*), guárdalo como `linkedin.png`
   (idealmente 96×96 px) y súbelo dentro de la carpeta `iconos`.
4. Ve a **Settings → Pages**:
   - **Source:** Deploy from a branch
   - **Branch:** `main` / carpeta `/ (root)` → **Save**
5. Espera 1–2 minutos. Tus imágenes quedarán en:

```
https://USUARIO.github.io/firma/iconos/linkedin.png
https://USUARIO.github.io/firma/iconos/email.png
https://USUARIO.github.io/firma/iconos/telefono.png
https://USUARIO.github.io/firma/iconos/ubicacion.png
https://USUARIO.github.io/firma/iconos/web.png
```

(reemplaza `USUARIO` por tu nombre de usuario de GitHub)

6. Abre `firma.html`, reemplaza `USUARIO` y el link de tu perfil de LinkedIn, y copia la firma a Outlook/Gmail.

## Reglas para que la URL nunca cambie

- No renombres ni muevas los archivos.
- Si actualizas un ícono, súbelo **con el mismo nombre** (la URL se mantiene).
- No borres el repositorio ni lo pases a privado.
